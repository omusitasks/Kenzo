class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if node is None:
            return 0
        return node.height

    def update_height(self, node):
        node.height = 1 + max(self.height(node.left), self.height(node.right))

    def get_balance(self, node):
        if node is None:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        self.update_height(z)
        self.update_height(y)

        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        self.update_height(z)
        self.update_height(y)

        return y

    def insert(self, root, key):
        if root is None:
            return AVLNode(key)
        elif key < root.key:
            root.left = self.insert(root.left, key)
        else:
            root.right = self.insert(root.right, key)

        self.update_height(root)

        balance = self.get_balance(root)

        # Left Left Case
        if balance > 1 and key < root.left.key:
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and key > root.right.key:
            return self.left_rotate(root)

        # Left Right Case
        if balance > 1 and key > root.left.key:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Left Case
        if balance < -1 and key < root.right.key:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root
    
    def inorder_traversal(self, root, result):
        if root:
            result = self.inorder_traversal(root.left, result)
            if isinstance(root, AVLNode):
                result.append(root.key)  # Assuming key attribute holds the Order object
            else:
                result.append(root)  # Append the Order object
            result = self.inorder_traversal(root.right, result)
        return result


    def search(self, root, key):
        if root is None or root.key == key:
            return root
        if root.key < key:
            return self.search(root.right, key)
        return self.search(root.left, key)

    def delete(self, root, key):
        if root is None:
            return root

        if key < root.key:
            root.left = self.delete(root.left, key)
        elif key > root.key:
            root.right = self.delete(root.right, key)
        else:
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
            temp = self.get_min_value_node(root.right)
            root.key = temp.key
            root.right = self.delete(root.right, temp.key)
        if root is None:
            return root

        self.update_height(root)

        balance = self.get_balance(root)

        # Left Left Case
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        # Left Right Case
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        # Right Left Case
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def get_min_value_node(self, root):
        current = root
        while current.left is not None:
            current = current.left
        return current


class Order:
    def __init__(self, orderId, currentSystemTime, orderValue, deliveryTime):
        self.orderId = orderId
        self.currentSystemTime = currentSystemTime
        self.orderValue = orderValue
        self.deliveryTime = deliveryTime
        self.priority = 0


class GatorGlideDelivery:
    def __init__(self):
        self.order_avl = AVLTree()
        self.eta_avl = AVLTree()
        self.current_time = 0

    def create_order(self, orderId, currentSystemTime, orderValue, deliveryTime):
        order = Order(orderId, currentSystemTime, orderValue, deliveryTime)
        self.order_avl.root = self.order_avl.insert(self.order_avl.root, order.priority)
        self.eta_avl.root = self.eta_avl.insert(self.eta_avl.root, currentSystemTime + deliveryTime)
        self.update_eta(order)  # Passing the entire order object
        return order



    def calculate_priority(self, order):
        valueWeight = 0.3
        timeWeight = 0.7
        normalizedOrderValue = order.orderValue / 50
        return valueWeight * normalizedOrderValue - timeWeight * order.currentSystemTime

    def update_eta(self, current_time):
        while True:
            min_eta = self.eta_avl.inorder_traversal(self.eta_avl.root, [])
            if not min_eta or (isinstance(min_eta[0], Order) and min_eta[0].currentSystemTime > current_time):
                break
            next_eta = min_eta[0].currentSystemTime  # Since min_eta should contain Order objects
            for order in min_eta:
                if self.calculate_eta(order.currentSystemTime, order.deliveryTime) <= current_time:
                    self.order_avl.root = self.order_avl.delete(self.order_avl.root, order.priority)
                    print(f"Order {order.orderId} has been delivered at time {current_time}")
                    next_eta = max(next_eta, self.calculate_eta(current_time, order.deliveryTime))
            self.eta_avl.root = self.eta_avl.delete(self.eta_avl.root, next_eta)
            print(f"Updated ETAs: {next_eta}")
            current_time = next_eta



    def calculate_eta(self, current_time, delivery_time):
        return current_time + delivery_time

    def cancel_order(self, orderId, currentSystemTime):
        order = self.order_avl.search(self.order_avl.root, orderId)
        if order:
            if self.calculate_eta(order.currentSystemTime, order.deliveryTime) <= currentSystemTime:
                print(f"Cannot cancel. Order {orderId} has already been delivered")
            else:
                self.order_avl.root = self.order_avl.delete(self.order_avl.root, order.priority)
                self.update_eta(currentSystemTime)
                print(f"Order {orderId} has been canceled")
        else:
            print(f"Order {orderId} not found")

    def print_orders_within_time(self, time1, time2):
        result = self.eta_avl.inorder_traversal(self.eta_avl.root, [])
        orders_to_deliver = [order for order in result if time1 <= order <= time2]
        if orders_to_deliver:
            print(orders_to_deliver)
        else:
            print("There are no orders in that time period")

    def print_order_details(self, orderId):
        order = self.order_avl.search(self.order_avl.root, orderId)
        if order:
            eta = self.calculate_eta(order.currentSystemTime, order.deliveryTime)
            print(f"[{order.orderId}, {order.currentSystemTime}, {order.orderValue}, {order.deliveryTime}, {eta}]")
        else:
            print(f"Order {orderId} not found")

    def get_rank_of_order(self, orderId):
        order = self.order_avl.search(self.order_avl.root, orderId)
        if order:
            order_priority = self.order_avl.inorder_traversal(self.order_avl.root, [])
            rank = order_priority.index(order.priority)
            print(f"Order {orderId} will be delivered after {rank} orders")
        else:
            print(f"Order {orderId} not found")


def process_input(input_filename):
    with open(input_filename, 'r') as file:
        lines = file.readlines()
    return lines


def process_output(output_filename, output):
    with open(output_filename, 'w') as file:
        for line in output:
            file.write(line + '\n')


def main():
    input_filename = input("Enter input filename: ")
    output_filename = input_filename.split('.')[0] + "_output_file.txt"
    input_lines = process_input(input_filename)
    delivery = GatorGlideDelivery()
    output = []
    for line in input_lines:
        command = line.strip().split('(')[0]
        args = line.strip().split('(')[1][:-1].split(', ')
        if command == "createOrder":
            orderId, currentSystemTime, orderValue, deliveryTime = map(int, args)
            order = delivery.create_order(orderId, currentSystemTime, orderValue, deliveryTime)
            eta = delivery.calculate_eta(order.currentSystemTime, order.deliveryTime)
            output.append(f"Order {orderId} has been created - ETA: {eta}")
        elif command == "cancelOrder":
            orderId, currentSystemTime = map(int, args)
            delivery.cancel_order(orderId, currentSystemTime)
        elif command == "print":
            if len(args) == 1:
                if args[0].isdigit():
                    orderId = int(args[0])
                    delivery.print_order_details(orderId)
                else:
                    time1, time2 = map(int, args[0].split(','))
                    delivery.print_orders_within_time(time1, time2)
            else:
                orderId = int(args[0])
                delivery.get_rank_of_order(orderId)
        elif command == "updateTime":
            orderId, currentSystemTime, newDeliveryTime = map(int, args)
            delivery.cancel_order(orderId, currentSystemTime)
            order = delivery.create_order(orderId, currentSystemTime, orderValue, newDeliveryTime)
            eta = delivery.calculate_eta(order.currentSystemTime, order.deliveryTime)
            output.append(f"Order {orderId} has been updated - ETA: {eta}")
    process_output(output_filename, output)


if __name__ == "__main__":
    main()































# import os

# class AVLNode:
#     def __init__(self, key):
#         self.key = key
#         self.left = None
#         self.right = None
#         self.height = 1


# class AVLTree:
#     def __init__(self):
#         self.root = None

#     def height(self, node):
#         if node is None:
#             return 0
#         return node.height

#     def update_height(self, node):
#         node.height = 1 + max(self.height(node.left), self.height(node.right))

#     def get_balance(self, node):
#         if node is None:
#             return 0
#         return self.height(node.left) - self.height(node.right)

#     def right_rotate(self, z):
#         y = z.left
#         T3 = y.right

#         y.right = z
#         z.left = T3

#         self.update_height(z)
#         self.update_height(y)

#         return y

#     def left_rotate(self, z):
#         y = z.right
#         T2 = y.left

#         y.left = z
#         z.right = T2

#         self.update_height(z)
#         self.update_height(y)

#         return y

#     def insert(self, root, key):
#         if root is None:
#             return AVLNode(key)
#         elif key < root.key:
#             root.left = self.insert(root.left, key)
#         else:
#             root.right = self.insert(root.right, key)

#         self.update_height(root)

#         balance = self.get_balance(root)

#         # Left Left Case
#         if balance > 1 and key < root.left.key:
#             return self.right_rotate(root)

#         # Right Right Case
#         if balance < -1 and key > root.right.key:
#             return self.left_rotate(root)

#         # Left Right Case
#         if balance > 1 and key > root.left.key:
#             root.left = self.left_rotate(root.left)
#             return self.right_rotate(root)

#         # Right Left Case
#         if balance < -1 and key < root.right.key:
#             root.right = self.right_rotate(root.right)
#             return self.left_rotate(root)

#         return root

#     def inorder_traversal(self, root, result):
#         if root:
#             result = self.inorder_traversal(root.left, result)
#             result.append(root.key)
#             result = self.inorder_traversal(root.right, result)
#         return result

#     def search(self, root, key):
#         if root is None or root.key == key:
#             return root
#         if root.key < key:
#             return self.search(root.right, key)
#         return self.search(root.left, key)

#     def delete(self, root, key):
#         if root is None:
#             return root

#         if key < root.key:
#             root.left = self.delete(root.left, key)
#         elif key > root.key:
#             root.right = self.delete(root.right, key)
#         else:
#             if root.left is None:
#                 temp = root.right
#                 root = None
#                 return temp
#             elif root.right is None:
#                 temp = root.left
#                 root = None
#                 return temp
#             temp = self.get_min_value_node(root.right)
#             root.key = temp.key
#             root.right = self.delete(root.right, temp.key)
#         if root is None:
#             return root

#         self.update_height(root)

#         balance = self.get_balance(root)

#         # Left Left Case
#         if balance > 1 and self.get_balance(root.left) >= 0:
#             return self.right_rotate(root)

#         # Left Right Case
#         if balance > 1 and self.get_balance(root.left) < 0:
#             root.left = self.left_rotate(root.left)
#             return self.right_rotate(root)

#         # Right Right Case
#         if balance < -1 and self.get_balance(root.right) <= 0:
#             return self.left_rotate(root)

#         # Right Left Case
#         if balance < -1 and self.get_balance(root.right) > 0:
#             root.right = self.right_rotate(root.right)
#             return self.left_rotate(root)

#         return root

#     def get_min_value_node(self, root):
#         current = root
#         while current.left is not None:
#             current = current.left
#         return current


# class Order:
#     def __init__(self, orderId, currentSystemTime, orderValue, deliveryTime):
#         self.orderId = orderId
#         self.currentSystemTime = currentSystemTime
#         self.orderValue = orderValue
#         self.deliveryTime = deliveryTime
#         self.priority = 0


# class GatorGlideDelivery:
#     def __init__(self):
#         self.order_avl = AVLTree()
#         self.eta_avl = AVLTree()
#         self.current_time = 0

#     def create_order(self, orderId, currentSystemTime, orderValue, deliveryTime):
#         order = Order(orderId, currentSystemTime, orderValue, deliveryTime)
#         # order.priority = self.calculate_priority(order)
#         order = self.create_order(orderId, currentSystemTime, orderValue, deliveryTime)
#         self.order_avl.root = self.order_avl.insert(self.order_avl.root, order.priority)
#         self.eta_avl.root = self.eta_avl.insert(self.eta_avl.root, currentSystemTime + deliveryTime)
#         self.update_eta(order.currentSystemTime)
#         return order

#     def calculate_priority(self, order):
#         valueWeight = 0.3
#         timeWeight = 0.7
#         normalizedOrderValue = order.orderValue / 50
#         return valueWeight * normalizedOrderValue - timeWeight * order.currentSystemTime
    

#     def update_eta(self, current_time):
#         while True:
#             min_eta = self.eta_avl.inorder_traversal(self.eta_avl.root, [])
#             if not min_eta or min_eta[0] > current_time:
#                 break
#             order_priority = self.order_avl.inorder_traversal(self.order_avl.root, [])
#             next_eta = min_eta[0]
#             for order in order_priority:
#                 if self.calculate_eta(order.currentSystemTime, order.deliveryTime) <= current_time:
#                     self.order_avl.root = self.order_avl.delete(self.order_avl.root, order)
#                     print(f"Order {order.orderId} has been delivered at time {current_time}")
#                     next_eta = max(next_eta, self.calculate_eta(current_time, order.deliveryTime))
#             self.eta_avl.root = self.eta_avl.delete(self.eta_avl.root, next_eta)
#             print(f"Updated ETAs: {next_eta}")
#             current_time = next_eta


#     def calculate_eta(self, current_time, delivery_time):
#         return current_time + delivery_time

#     def cancel_order(self, orderId, currentSystemTime):
#         order = self.order_avl.search(self.order_avl.root, orderId)
#         if order:
#             if self.calculate_eta(order.currentSystemTime, order.deliveryTime) <= currentSystemTime:
#                 print(f"Cannot cancel. Order {orderId} has already been delivered")
#             else:
#                 self.order_avl.root = self.order_avl.delete(self.order_avl.root, order.priority)
#                 self.update_eta(currentSystemTime)
#                 print(f"Order {orderId} has been canceled")
#         else:
#             print(f"Order {orderId} not found")

#     def print_orders_within_time(self, time1, time2):
#         result = self.eta_avl.inorder_traversal(self.eta_avl.root, [])
#         orders_to_deliver = [order for order in result if time1 <= order <= time2]
#         if orders_to_deliver:
#             print(orders_to_deliver)
#         else:
#             print("There are no orders in that time period")

#     def print_order_details(self, orderId):
#         order = self.order_avl.search(self.order_avl.root, orderId)
#         if order:
#             eta = self.calculate_eta(order.currentSystemTime, order.deliveryTime)
#             print(f"[{order.orderId}, {order.currentSystemTime}, {order.orderValue}, {order.deliveryTime}, {eta}]")
#         else:
#             print(f"Order {orderId} not found")

#     def get_rank_of_order(self, orderId):
#         order = self.order_avl.search(self.order_avl.root, orderId)
#         if order:
#             order_priority = self.order_avl.inorder_traversal(self.order_avl.root, [])
#             rank = order_priority.index(order.priority)
#             print(f"Order {orderId} will be delivered after {rank} orders")
#         else:
#             print(f"Order {orderId} not found")



# def process_input(input_filename):
#   full_path = os.path.abspath(input_filename)
#   print(full_path)  # Add this line to print the full path
#   with open(full_path, 'r') as file:
#     lines = file.readlines()
#   return lines


# def process_output(output_filename, output):
#     with open(output_filename, 'w') as file:
#         for line in output:
#             file.write(line + '\n')

# def main():
#     input_filename = input("Enter full path to input filename: ")
#     output_filename = input_filename.split('.')[0] + "_output_file.txt"
#     input_lines = process_input(input_filename)
#     delivery = GatorGlideDelivery()
#     output = []
#     for line in input_lines:
#         command = line.strip().split('(')[0]
#         args = line.strip().split('(')[1][:-1].split(', ')
#         if command == "createOrder":
#             orderId, currentSystemTime, orderValue, deliveryTime = map(int, args)
#             order = delivery.create_order(orderId, currentSystemTime, orderValue, deliveryTime)
#             eta = delivery.calculate_eta(order.currentSystemTime, order.deliveryTime)
#             output.append(f"Order {orderId} has been created - ETA: {eta}")
#         elif command == "cancelOrder":
#             orderId, currentSystemTime = map(int, args)
#             delivery.cancel_order(orderId, currentSystemTime)
#         elif command == "print":
#             if len(args) == 1:
#                 if args[0].isdigit():
#                     orderId = int(args[0])
#                     delivery.print_order_details(orderId)
#                 else:
#                     time1, time2 = map(int, args[0].split(','))
#                     delivery.print_orders_within_time(time1, time2)
#             else:
#                 orderId = int(args[0])
#                 delivery.get_rank_of_order(orderId)
#         elif command == "updateTime":
#             orderId, currentSystemTime, newDeliveryTime = map(int, args)
#             delivery.cancel_order(orderId, currentSystemTime)
#             order = delivery.create_order(orderId, currentSystemTime, orderValue, newDeliveryTime)
#             eta = delivery.calculate_eta(order.currentSystemTime, order.deliveryTime)
#             output.append(f"Order {orderId} has been updated - ETA: {eta}")
#     process_output(output_filename, output)

# if __name__ == "__main__":
#     main()