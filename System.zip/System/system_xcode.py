import sys

class AVLNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def update_height(self, node):
        if not node:
            return
        node.height = 1 + max(self.height(node.left), self.height(node.right))

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        self.update_height(z)
        self.update_height(y)

        return y

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        self.update_height(z)
        self.update_height(y)

        return y

    def insert(self, node, key):
        if not node:
            return AVLNode(key)

        if key < node.key:
            node.left = self.insert(node.left, key)
        elif key > node.key:
            node.right = self.insert(node.right, key)
        else:
            return node

        self.update_height(node)

        balance = self.get_balance(node)

        # Left Left Case
        if balance > 1 and key < node.left.key:
            return self.right_rotate(node)

        # Right Right Case
        if balance < -1 and key > node.right.key:
            return self.left_rotate(node)

        # Left Right Case
        if balance > 1 and key > node.left.key:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        # Right Left Case
        if balance < -1 and key < node.right.key:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def inorder_traversal(self, node, result):
        if node:
            self.inorder_traversal(node.left, result)
            result.append(node.key)
            self.inorder_traversal(node.right, result)

def calculate_priority(order_value, order_creation_time):
    value_weight = 0.3
    time_weight = 0.7
    normalized_order_value = order_value / 50
    return value_weight * normalized_order_value - time_weight * order_creation_time

class GatorGlideDeliverySystem:
    def __init__(self):
        self.order_priority_tree = AVLTree()
        self.order_eta_tree = AVLTree()
        self.current_time = 0

    def create_order(self, order_id, current_system_time, order_value, delivery_time):
        priority = calculate_priority(order_value, current_system_time)
        self.order_priority_tree.root = self.order_priority_tree.insert(self.order_priority_tree.root, priority)
        self.order_eta_tree.root = self.order_eta_tree.insert(self.order_eta_tree.root, current_system_time + priority)
        eta = current_system_time + priority
        print(f"Order {order_id} has been created - ETA: {eta}")

        orders_to_deliver = self.get_orders_to_deliver(current_system_time)
        for order in orders_to_deliver:
            print(f"Order {order[0]} has been delivered at time {order[1]}")

    def cancel_order(self, order_id, current_system_time):
        # Implementation for cancelOrder goes here
        pass

    def update_time(self, order_id, current_system_time, new_delivery_time):
        # Implementation for updateTime goes here
        pass

    def get_orders_to_deliver(self, current_system_time):
        orders_to_deliver = []
        self.current_time = current_system_time

        while self.order_eta_tree.root and self.order_eta_tree.root.key <= current_system_time:
            min_eta = self.order_eta_tree.root.key
            self.order_eta_tree.root = self.delete_node(self.order_eta_tree.root, min_eta)

            orders_to_deliver.append((min_eta, self.current_time))

        return orders_to_deliver

    def delete_node(self, root, key):
        if not root:
            return root

        if key < root.key:
            root.left = self.delete_node(root.left, key)
        elif key > root.key:
            root.right = self.delete_node(root.right, key)
        else:
            if not root.left:
                temp = root.right
                root = None
                return temp
            elif not root.right:
                temp = root.left
                root = None
                return temp

            temp = self.min_value_node(root.right)
            root.key = temp.key
            root.right = self.delete_node(root.right, temp.key)

        if not root:
            return root

        root.height = 1 + max(self.order_priority_tree.height(root.left), self.order_priority_tree.height(root.right))

        balance = self.order_priority_tree.get_balance(root)

        # Left Left Case
        if balance > 1 and self.order_priority_tree.get_balance(root.left) >= 0:
            return self.order_priority_tree.right_rotate(root)

        # Left Right Case
        if balance > 1 and self.order_priority_tree.get_balance(root.left) < 0:
            root.left = self.order_priority_tree.left_rotate(root.left)
            return self.order_priority_tree.right_rotate(root)

        # Right Right Case
        if balance < -1 and self.order_priority_tree.get_balance(root.right) <= 0:
            return self.order_priority_tree.left_rotate(root)

        # Right Left Case
        if balance < -1 and self.order_priority_tree.get_balance(root.right) > 0:
            root.right = self.order_priority_tree.right_rotate(root.right)
            return self.order_priority_tree.left_rotate(root)

        return root

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

def parse_input(input_file):
    operations = []
    with open(input_file, 'r') as file:
        for line in file:
            line = line.strip()
            if line == "Quit()":
                operations.append(("Quit",))
            else:
                operations.append(tuple(line.split(" ", 1)))
    return operations


def main():
    if len(sys.argv) != 2:
        print("Usage: python program.py input_filename")
        return

    input_filename = sys.argv[1]
    output_filename = input_filename.split('.')[0] + "_output_file.txt"

    delivery_system = GatorGlideDeliverySystem()
    operations = parse_input(input_filename)

    output = []
    for operation in operations:
        if operation[0] == "Quit":
            break
        elif operation[0] == "createOrder":
            params = operation[1].strip("()").split(", ")
            order_id, current_system_time, order_value, delivery_time = map(int, params)
            delivery_system.create_order(order_id, current_system_time, order_value, delivery_time)
        elif operation[0] == "cancelOrder":
            params = operation[1].strip("()").split(", ")
            order_id, current_system_time = map(int, params)
            delivery_system.cancel_order(order_id, current_system_time)
        elif operation[0] == "updateTime":
            params = operation[1].strip("()").split(", ")
            order_id, current_system_time, new_delivery_time = map(int, params)
            delivery_system.update_time(order_id, current_system_time, new_delivery_time)
        elif operation[0] == "print":
            params = operation[1].strip("()").split(", ")
            if len(params) == 1:
                order_id = int(params[0])
                output.append(delivery_system.print_order(order_id))
            elif len(params) == 2:
                time1, time2 = map(int, params)
                output.append(delivery_system.print_orders_within_times(time1, time2))
        else:
            output.append("Invalid operation")

    with open(output_filename, 'w') as file:
        file.write('\n'.join(output))

if __name__ == "__main__":
    main()

