<?php

$conn = mysqli_connect('localhost','root','1234','user_db');

?>

