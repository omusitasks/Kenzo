# install.packages("recommenderlab")
# install.packages("arules")
# install.packages("reshape2")
# install.packages("Matrix")
# install.packages("svDialogs")
# install.packages("syuzhet")
# The above install packages are for the packages that are not as common.
# If you need to install any of the other packages below do so as well.

library(recommenderlab)
library(svDialogs)
library(tidyverse)
library(ggplot2)
library(syuzhet)
library(data.table)
library(dplyr)


# Read Core file - This is Book Data or Movie Data or any other Item Data CSV file.
core_data <- read.csv(file.choose(), header = T)
# Display the structure of the core_data data frame
str(core_data)
# Display a summary of the core_data data frame
summary(core_data)
# Display the first n-number of records of the core_data data frame
head(core_data)

# Rename the core import csv columns to make working with various types of data (Verify data is in this order first)
colnames(core_data)[1:3] <- c("core_id", "title", "descripts")

# Verify core Column Names
head(core_data)
# summary
summary(core_data)

# Read Rating file - This is Rating Data CSV file
rating_data <- read.csv(file.choose(), header = T)
str(rating_data)
summary(rating_data)
head(rating_data)

# Rename the rating import csv columns to make working with various rating data
colnames(rating_data)[1:3] <- c("user_id", "core_id", "rating")

# Verify rating Column Names
head(rating_data)

#summary
summary(rating_data)

# Determine which type of Recommendation you want to run 
# Choose between 0 = IBCF(Item-Based Collaborative Filtering) or 1 = UBCF (User-Based Collaborative Filtering)
flag <- dlgInput("Choose between 0 = IBCF(Item-Based Collaborative Filtering) or 1 = UBCF (User-Based Collaborative Filtering)", 0)$res

# Create a data set of core_data descripts column 
descripts <- as.data.frame(core_data$descripts, stringsAsFactors=FALSE)
# Break out the descripts column data using the Pipe | as the delimiter
descripts2 <- as.data.frame(tstrsplit(descripts[,1], '[|]', 
                                        type.convert=TRUE), 
                              stringsAsFactors=FALSE) 

colnames(descripts2) <- c(1:ncol(descripts2))

# Here we are generating the list of available characteristics, descriptors, tags, traits, etc. 
list_d <- unique(descripts2[c("1")])

list_dd=list(list_d[,1])

list_descripts <- unlist(list_dd)

listcount = length(list_descripts)

# Old way do not use
#list_descripts <- c("Action", "Adventure", "Animation", "Children", 
#                "Comedy", "Crime","Documentary", "Drama", "Fantasy",
#                "Film-Noir", "Horror", "Musical", "Mystery","Romance",
#                "Sci-Fi", "Thriller", "War", "Western")

sample(list_descripts, sample(1:4),replace=TRUE)

# Create a Matrix of descriptors to be used with the core_data to create a search matrix
descripts_mat1 <- matrix(0,nrow(core_data)+1,listcount) 
str(descripts_mat1)
head(descripts_mat1)
# The center number nrow(core_data)+1 is set to one more than the number of records you extracted i.e 10001 for the 10000 rows extracted. 
# Also, In this case listcount represents the number of descriptors.
descripts_mat1[1,] <- list_descripts
colnames(descripts_mat1) <- list_descripts
for (index in 1:nrow(descripts2)) {
  for (col in 1:ncol(descripts2)) {
    gen_col = which(descripts_mat1[1,] == descripts2[index,col]) 
    descripts_mat1[index+1,gen_col] <- 1
  }
}
descripts_mat2 <- as.data.frame(descripts_mat1[-1,], stringsAsFactors=FALSE) # remove first row, which was the descripts list
for (col in 1:ncol(descripts_mat2)) {
  descripts_mat2[,col] <- as.integer(descripts_mat2[,col]) #convert from characters to integers
} 
str(descripts_mat2)
head(descripts_mat2)

SearchMatrix <- cbind(core_data[,1:2], descripts_mat2[])
head(SearchMatrix)

# Create a Rating Matrix from the rating_data data frame. 
ratingMatrix <- reshape2::dcast(rating_data, user_id~core_id, value.var = "rating", na.rm=FALSE)
ratingMatrix <- as.matrix(ratingMatrix[,-1]) #remove userIds
#Convert rating matrix into a recommenderlab sparse matrix
ratingMatrix <- as(ratingMatrix, "realRatingMatrix")
ratingMatrix # Keep Track of the numbers in this Matrix
rm_results <- capture.output(ratingMatrix)

rm_res_str <- str_match(rm_results, "x\\s*(.*?)\\s*rating")

rm_res_num <- strtoi(rm_res_str[,2]) 

recommendation_model <- recommenderRegistry$get_entries(dataType = "realRatingMatrix")
names(recommendation_model)

lapply(recommendation_model, "[[", "description")

# Based on the IBCF/UBCF option you chose above # IBCF(Item-Based Collaborative Filtering). # UBCF (User-Based Collaborative Filtering).
{
if (flag == 0) 
  { recommendation_model$IBCF_realRatingMatrix$parameters 
} else (flag == 1) 
  {recommendation_model$UBCF_realRatingMatrix$parameters 
  }
}

similarity_mat <- similarity(ratingMatrix[1:4, ],
                             method = "cosine",
                             which = "users")
as.matrix(similarity_mat)
image(as.matrix(similarity_mat), main = "User's Similarities")

core_similarity <- similarity(ratingMatrix[, 1:4], method =
                                 "cosine", which = "items")
as.matrix(core_similarity)
image(as.matrix(core_similarity), main = "Item similarity")

rating_values <- as.vector(ratingMatrix@data)
unique(rating_values) # extracting unique ratings

Table_of_Ratings <- table(rating_values) # creating a count of core item ratings
Table_of_Ratings

core_views <- colCounts(ratingMatrix) # count views for each core item
table_views <- data.frame(core = names(core_views),
                          views = core_views) # create dataframe of views
table_views <- table_views[order(table_views$views,
                                 decreasing = TRUE), ] # sort by number of views

# Make sure to set the number to the right of the : in the for statement below to the number of records you extracted i.e 10000 for the 10000 rows extracted.
table_views$title <- NA
for (index in 1:rm_res_num){
  table_views[index,3] <- as.character(subset(core_data,
                                              core_data$core_id == table_views[index,1])$title)
}

table_views[1:10,]

ggplot(table_views[1:10, ], aes(x = title, y = views)) +
  geom_bar(stat="identity", fill = 'steelblue') +
  geom_text(aes(label=views), vjust=-0.3, size=3.5) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  ggtitle("Total views of the Top Core Item")

image(ratingMatrix[1:25, 1:25], axes = FALSE, main = "Heatmap of the first 25 rows and 25 columns")

core_ratings <- ratingMatrix[rowCounts(ratingMatrix) > 50,
                              colCounts(ratingMatrix) > 50]
core_ratings

minimum_cores<- quantile(rowCounts(core_ratings), 0.98)
minimum_users <- quantile(colCounts(core_ratings), 0.98)
image(core_ratings[rowCounts(core_ratings) > minimum_cores,
                    colCounts(core_ratings) > minimum_users],
      main = "Heatmap of the top users and items")

average_ratings <- rowMeans(core_ratings)
qplot(average_ratings, fill=I("steelblue"), col=I("red")) +
  ggtitle("Distribution of the average rating per user")

normalized_ratings <- normalize(core_ratings)
sum(rowMeans(normalized_ratings) > 0.00001)
image(normalized_ratings[rowCounts(normalized_ratings) > minimum_cores,
                         colCounts(normalized_ratings) > minimum_users],
      main = "Normalized Ratings of the Top Users")

binary_minimum_cores <- quantile(rowCounts(core_ratings), 0.95)
binary_minimum_users <- quantile(colCounts(core_ratings), 0.95)

good_rated_cores <- binarize(core_ratings, minRating = 3)
image(good_rated_cores[rowCounts(core_ratings) > binary_minimum_cores,
                       colCounts(core_ratings) > binary_minimum_users],
      main = "Heatmap of the top users and items")

sampled_data<- sample(x = c(TRUE, FALSE),
                      size = nrow(core_ratings),
                      replace = TRUE,
                      prob = c(0.8, 0.2))
training_data <- core_ratings[sampled_data, ]
testing_data <- core_ratings[!sampled_data, ]

recommendation_system <- recommenderRegistry$get_entries(dataType ="realRatingMatrix")

# Based on the IBCF/UBCF option you chose above
{
if (flag == 0) {
  recommendation_system$IBCF_realRatingMatrix$parameters
  } else if (flag == 1) {
  recommendation_system$UBCF_realRatingMatrix$parameters 
  }
}

{
  if (flag == 0) {
recommen_model <- Recommender(data = training_data,
                              method = "IBCF",
                              parameter = list(k = 30))
  } else if (flag == 1) {
recommen_model <- Recommender(data = training_data,
                              method = "UBCF",
                              parameter = list(nn = 30))
  }
}

recommen_model
class(recommen_model)

model_info <- getModel(recommen_model)

{
  if (flag == 0) {
    class(model_info$sim)
    dim(model_info$sim)
  } else if (flag == 1) {
    class(model_info$data) 
    dim(model_info$data)
  }
}

top_recommendations <- dlgInput("Choose number between 1 & 10 the number of items to recommend to each user", 5)$res

predicted_recommendations <- predict(object = recommen_model,
                                     newdata = testing_data,
                                     n = top_recommendations)
predicted_recommendations

# predicted_recommendations will display the total number of available users to chose from we capture that value to use in our random user generator below

results <- capture.output(predicted_recommendations)

res_str <- str_match(results, "for\\s*(.*?)\\s*users")

res_num <- strtoi(res_str[,2]) 

# Generate a random user 
random_user <- sample(1:res_num, 1, replace=TRUE)

user1 <- predicted_recommendations@items[[random_user]] # recommendation for the random user
items_user1 <- predicted_recommendations@itemLabels[user1]
items_user1map <- items_user1
for (index in 1:top_recommendations){
  items_user1map[index] <- as.character(subset(core_data,
                                             core_data$core_id == items_user1[index])$title)
}
items_user1map

recommendation_matrix <- sapply(predicted_recommendations@items,
                                function(x){ as.integer(colnames(core_ratings)[x]) }) # matrix with the recommendations for each user
#dim(recc_matrix)
recommendation_matrix[1:top_recommendations]

