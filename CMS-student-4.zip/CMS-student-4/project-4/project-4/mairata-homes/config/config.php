<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'last');
define('DB_USER', 'root');
define('DB_PASS', '1234');
