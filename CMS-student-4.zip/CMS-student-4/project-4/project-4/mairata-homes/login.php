<?php
include 'inc/header.php';
Session::CheckLogin();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $userLog = $users->userLoginAuthotication($_POST);

    if ($userLog === 'Login Successful') {
        // Fetch user details after successful login
        $loggedInUser = $users->getUserDataByUsername($_POST['username']); // Modify this function according to your implementation
        
        if ($loggedInUser && isset($loggedInUser['roleid'])) {
            $roleid = $loggedInUser['roleid'];

            if ($roleid == 1) {
                // Redirect user with roleid = 1 to index.php
                header('Location: index.php');
                exit(); // Make sure to exit after header redirection
            } elseif ($roleid == 2) {
                // Redirect user with roleid = 2 to user_page.php
                header('Location: user_page.php');
                exit(); // Make sure to exit after header redirection
            }
        }
    }
}

if (isset($userLog)) {
    echo $userLog;
}

$logout = Session::get('logout');
if (isset($logout)) {
    echo $logout;
}
?>

<div class="card ">
  <div class="card-header">
          <h3 class='text-center'><i class="fas fa-sign-in-alt mr-2"></i>User login</h3>
        </div>
        <div class="card-body">


            <div style="width:450px; margin:0px auto">

            <form class="" action="" method="post">
                <div class="form-group">
                  <label for="username">Username</label>
                  <input type="text" name="username"  class="form-control">
                </div>
                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" name="password"  class="form-control">
                </div>
                <div class="form-group">
                  <button type="submit" name="login" class="btn btn-success">Login</button>
                </div>


            </form>
          </div>


        </div>
      </div>



  <?php
  include 'inc/footer.php';

  ?>
