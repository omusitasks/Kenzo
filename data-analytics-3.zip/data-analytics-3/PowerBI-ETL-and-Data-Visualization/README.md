
# PowerBI: ETL and Data Visualization

In this project we implement an ETL process (extract, transform and load) and dashboard design in PowerBI for Amazon Top 50 Bestselling Books dataset.


## Tech Stack

PowerBI, Numerro


## Documentation

[Dataset](https://www.kaggle.com/sootersaalu/amazon-top-50-bestselling-books-2009-2019)

[PowerBI](https://powerbi.microsoft.com/en-us/learning/)

[Numerro](https://www.numerro.io/content-hub-home)

