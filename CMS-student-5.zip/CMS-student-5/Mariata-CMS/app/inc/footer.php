<!--====== JQuery from CDN ======-->
<script src="assets/js/jquery.min.js"></script>

<!--====== Bootstrap js ======-->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/popper.min.js"></script>

<!--====== datepicker js ======-->
<script src="assets/js/moment-with-locales.min.js"></script>
<script src="assets/js/bootstrap-datetimepicker.min.js"></script>

<!--====== select2.min.js ======-->
<script src="assets/js/select2.min.js"></script>

<!--====== dataTables js ======-->
<script src="assets/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/js/jquery.dataTables.min.js"></script>

<!--====== Chart.min js ======-->
<script src="assets/js/Chart.bundle.min.js"></script>

<!--====== wow.min js ======-->
<script src="assets/js/wow.min.js"></script>
<!--====== Main js ======-->
<script src="assets/js/script.js"></script>
<script type="text/javascript">
(function($) {
   $(function() {
      $('#id_0').datetimepicker({
         "allowInputToggle": true,
         "showClose": true,
         "showClear": true,
         "showTodayButton": true,
         "format": "YYYY/MM/DD hh:mm:ss ",
      });

   });
})(jQuery);
</script>





</body>

</html>