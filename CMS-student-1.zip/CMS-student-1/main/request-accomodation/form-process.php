<?php
include("config.php");
extract($_POST);
$sql = "INSERT INTO `RecommendedSources`(`SourceAddress`, `SourceName`) VALUES ('".$SourceAddress."','".$SourceName."')";

$result = $conn->query($sql);
if(!$result){
    die("Couldn't enter data: ".$conn->error);
}
echo "Thank You For Contacting Us ";
$conn->close();
?>


