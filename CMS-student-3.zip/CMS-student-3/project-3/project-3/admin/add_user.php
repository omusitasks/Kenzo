<?php
@include 'config.php';

$message = ''; // Initialize an empty message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   // Retrieving form data
   $name = isset($_POST['Name']) ? mysqli_real_escape_string($conn, $_POST['Name']) : '';
   $DOB = isset($_POST['DOB']) ? $_POST['DOB'] : '';
   $Telephone = isset($_POST['Telephone']) ? $_POST['Telephone'] : '';
   $NextOfKin = isset($_POST['NextOfKin']) ? $_POST['NextOfKin'] : '';
   $Age = isset($_POST['Age']) ? $_POST['Age'] : '';
   $LastResidenceAddress = isset($_POST['LastResidenceAddress']) ? mysqli_real_escape_string($conn, $_POST['LastResidenceAddress']) : '';
   $email = isset($_POST['email']) ? mysqli_real_escape_string($conn, $_POST['email']) : '';
   $password = isset($_POST['password']) ? $_POST['password'] : '';


       // Hash the password for security
       $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

   // Check if the email already exists
   $select = "SELECT * FROM User WHERE email = '$email'";
   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){
      $message = 'User already exists!';
   } else {
    //   // Adjust the INSERT query to match your table columns
    //   $insert = "INSERT INTO User (name, DOB, Telephone, NextOfKin, Age, LastResidenceAddress, email) VALUES ('$name','$DOB','$Telephone','$NextOfKin','$Age','$LastResidenceAddress','$email')";
      
    //   if(mysqli_query($conn, $insert)) {
    //      $message = 'User added successfully!';
    //   } else {
    //      $message = 'Error adding user: ' . mysqli_error($conn);
    //   }
        // Insert the user details into the database
        $query = "INSERT INTO User (Name, DOB, Telephone, NextOfKin, Age, LastResidenceAddress, email, password) 
        VALUES ('$name', '$DOB', '$Telephone', '$NextOfKin', '$Age', '$LastResidenceAddress', '$email', '$hashedPassword')";

if (mysqli_query($conn, $query)) {
    $message = "User added successfully!";
} else {
   $message = "Error: " . mysqli_error($conn);
}
   }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Users</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-success">
  <div class="container">
    <a class="navbar-brand" href="index.php">Admin Dashboard </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Add New User</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="list_users.php">View Users</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-danger" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Account
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
          </ul>
        </li>
       
      </ul>
    </div>
  </div>
</nav>

<div class="container">


<form  action="" method="post">
<div class="container">
   <?php if(!empty($message)) { ?>
      <div class="alert <?php echo (strpos($message, 'success') !== false) ? 'alert-success' : 'alert-danger'; ?>">
         <?php echo $message; ?>
      </div>
   <?php } ?>
   <!-- Your existing HTML form goes here -->
</div>
<div class="row">
    <div class="col">
      <input type="text" class="form-control" name="Name" placeholder="Name" required>
    </div>
    <div class="col">
      <input type="text" class="form-control" name="DOB" placeholder="Date of Birth" required>
    </div>
  </div>

  <div class="row">
    <div class="col">
      <input type="text" class="form-control" name="Telephone" placeholder="Telephone" required>
    </div>
    <div class="col">
      <input type="text" class="form-control" name="NextOfKin" placeholder="NextOfKin" required>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <input type="number" class="form-control" name="Age" placeholder="Age" required>
    </div>
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="Email" required>
    </div>
    <div class="col">
      <input type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
  </div>
  <div class="form-group">
    <label for="LastResidenceAddress">LastResidenceAddress</label>
    <input type="text" class="form-control" id="LastResidenceAddress" placeholder="1234 Main St" required>
  </div>

  <button type="submit" class="btn btn-primary">Add New User</button>
</form>
</div>
</body>
</html>