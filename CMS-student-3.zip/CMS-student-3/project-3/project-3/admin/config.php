<?php

$conn = mysqli_connect('localhost','root','','main_one');

?>