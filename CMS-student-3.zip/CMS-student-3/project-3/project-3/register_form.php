<?php
@include 'config.php';

if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $DOB = $_POST['DOB'];
    $Telephone = $_POST['Telephone'];
    $NextOfKin = $_POST['NextOfKin'];
    $Age = $_POST['Age'];
    $LastResidenceAddress = mysqli_real_escape_string($conn, $_POST['LastResidenceAddress']);

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = md5($_POST['password']);
    $cpass = md5($_POST['cpassword']);
    $user_type = $_POST['user_type'];

    $select = "SELECT * FROM User WHERE email = '$email' && password = '$pass'";
    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $error[] = 'User already exists!';
    } else {
        if ($pass != $cpass) {
            $error[] = 'Passwords do not match!';
        } else {
            $insert = "INSERT INTO User (name, DOB, Telephone, NextOfKin, Age, LastResidenceAddress, username, email, password, user_type) VALUES ('$name', '$DOB', '$Telephone', '$NextOfKin', '$Age', '$LastResidenceAddress', '$username', '$email', '$pass', '$user_type')";
            mysqli_query($conn, $insert);
            $success_message = 'Registration successful!';
            header('location: login_form.php');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <title>Mariata Homes</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar">
  <div class="container">
    <a class="navbar-brand" href="index.php">Mariata Homes </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about_page.php">About Us</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-danger" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Account
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="login_form.php">Login</a></li>
            <li><a class="dropdown-item" href="register_form.php">Register</a></li>
          </ul>
        </li>
       
      </ul>
    </div>
  </div>
</nav>
<div class="form-container">

   <form action="" method="post">
      <h3>Register now</h3>
      <?php
            if (isset($error)) {
                foreach ($error as $error) {
                    echo '<span class="error-msg">' . $error . '</span>';
                }
            }
            if (isset($success_message)) {
                echo '<span class="success-msg">' . $success_message . '</span>';
            }
            ?>

      <input type="text" name="name" required placeholder="Enter your name">
      <input type="text" name="DOB" required placeholder="Enter your DOB">
      <input type="text" name="Telephone" required placeholder="Enter your Telephone">
      <input type="text" name="NextOfKin" required placeholder="Enter name of your NextOfKin">
      <input type="number" name="Age" required placeholder="Enter your Age">
      <input type="text" name="LastResidenceAddress" required placeholder="Enter name of your LastResidenceAddress">

      <input type="text" name="username" required placeholder="enter your username">
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="password" name="cpassword" required placeholder="confirm your password">
      <select name="user_type">
         <option value="user">user</option>
         <option value="admin">admin</option>
      </select>
      <input type="submit" name="submit" value="register now" class="form-btn">
      <p>already have an account? <a href="login_form.php">login now</a></p>
   </form>

</div>

</body>
</html>