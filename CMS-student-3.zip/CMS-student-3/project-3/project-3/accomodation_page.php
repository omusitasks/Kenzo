<?php
session_start();

@include 'config.php';

$success_message = ''; // Initialize an empty success message variable

if(isset($_POST['submit'])){
    if(isset($_SESSION['UserID'])) {
        $UserID = $_SESSION['UserID'];
        $RecommendedSource = mysqli_real_escape_string($conn, $_POST['RecommendedSource']);
        $RecommendedSourceAddress = mysqli_real_escape_string($conn, $_POST['RecommendedSourceAddress']);
        $Illness = mysqli_real_escape_string($conn, $_POST['Illness']);

        $targetDir = "uploads/"; // Directory where the uploaded files will be stored
        $targetFile = $targetDir . basename($_FILES["Photograph"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if the file has been uploaded
        if (move_uploaded_file($_FILES["Photograph"]["tmp_name"], $targetFile)) {
            // Insert into RecommendedSource table
            $insertRecommended = "INSERT INTO RecommendedSource (UserID, RecommendedSource, RecommendedSourceAddress) 
                       VALUES ('$UserID','$RecommendedSource','$RecommendedSourceAddress')";
            $resultRecommended = mysqli_query($conn, $insertRecommended);

            // Insert into Illness table
            $insertIllness = "INSERT INTO Illness (UserID, Illness) VALUES ('$UserID','$Illness')";
            $resultIllness = mysqli_query($conn, $insertIllness);

            // Insert into PassportPhotograph table
            $insertPhotograph = "INSERT INTO PassportPhotograph (UserID, Photograph) VALUES ('$UserID','$targetFile')";
            $resultPhotograph = mysqli_query($conn, $insertPhotograph);

            if ($resultRecommended && $resultIllness && $resultPhotograph) {
                $success_message = 'Thanks, you have successfully submitted your details!';
            } else {
                $success_message = 'Form submission failed. Please try again.';
            }
        } else {
            $success_message = 'File upload failed.';
        }
    } else {
        $success_message = 'UserID is not set in the session.';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


</head>
<body>
<nav class="navbar navbar-expand-lg navbar">
  <div class="container">
    <a class="navbar-brand" href="#">Mariata Homes </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about_page.php">About Us</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-danger" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Account
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
          </ul>
        </li>
       
      </ul>
    </div>
  </div>
</nav>
<div class="container">

<div class="container">

        <div class="form-container">
            <form action="" method="post" enctype="multipart/form-data">
            <?php if (!empty($success_message)) : ?>
                <!-- Display the success message if it's not empty -->
                <div class="alert alert-success" role="alert">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
                <h3>Accommodation Form</h3>
                <!-- ... (your form inputs) ... -->
                <span><label for="RecommendedSource">RecommendedSource</label></span>
                <input type="text" name="RecommendedSource" required placeholder="enter your RecommendedSource">
                <span><label for="RecommendedSourceAddress">RecommendedSourceAddress</label></span>
                <input type="text" name="RecommendedSourceAddress" required placeholder="enter your RecommendedSourceAddress">
                <span><label for="Illiness">State your Illness</label></span>
                <input type="text" name="Illness" required placeholder="enter your illness"> <!-- Adding input for Illness -->
                <span><label for="Photograph">Passport Photo</label></span>
                <input type="file" name="Photograph" required accept="image/*"> <!-- File input for Photograph -->
                <input type="submit" name="submit" value="Apply now" class="form-btn">
            </form>
        </div>
    </div>


</body>
</html>