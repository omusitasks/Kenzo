DROP DATABASE main_one;
CREATE DATABASE main_one;

USE main_one;

-- User Table
CREATE TABLE User (
    `UserID` INT PRIMARY KEY AUTO_INCREMENT,
    `Name` VARCHAR(50),
    `DOB` VARCHAR(50),
    `username` VARCHAR(50)  NOT NULL,
    `email` VARCHAR(50)  NOT NULL,
    `password` VARCHAR(250)  NOT NULL,
    `Telephone` VARCHAR(20),
    `NextOfKin` VARCHAR(50),
    `Age` INT,
    `LastResidenceAddress` VARCHAR(100)
);

ALTER TABLE User
ADD COLUMN user_type VARCHAR(20) DEFAULT 'user';


-- RecommendedSource Table
CREATE TABLE RecommendedSource (
    `RecommendedSourceID` INT PRIMARY KEY AUTO_INCREMENT,
    `UserID` INT,
    `RecommendedSource` VARCHAR(50),
    `RecommendedSourceAddress` VARCHAR(100),
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);

-- Illness Table
CREATE TABLE Illness (
    IllnessID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    Illness VARCHAR(50),
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);

-- PassportPhotograph Table
CREATE TABLE PassportPhotograph (
    PassportPhotographID INT PRIMARY KEY AUTO_INCREMENT,
    UserID INT,
    Photograph BLOB, -- Assuming storing images as binary data (BLOB)
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);
